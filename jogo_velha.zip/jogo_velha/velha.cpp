/*Nome:Bernardo Aleixo Correa,Victhor Cani e Matheus Hamerski

Programa mais simples possivel que imprime um jogo da velha para melhor diversão.*/
	#include <iostream>
	#include "velha.h"
		
using namespace std;





int main()
{
	system("chcp 65001");
    int board[3][3];
    
   		
		
		
    int cont=0, player1=0, player2=0, result;
	
    do{
        iniciar(board);
        result = jogo(board);
        mostrar(board);
        placar(result, player1, player2);

        cout<<"\n Outra partida?"<<endl;
        cout<<"0. Sair"<<endl;
        cout<<"1. Jogar de novo"<<endl;
        cin >> cont;
    }while(cont);

    return 0;
}



/*
    0 = Preto        8 = Cinza
    1 = Azul         9 = Azul claro
    2 = Verde        A = Verde claro
    3 = Verde-água   B = Verde-água claro
    4 = Vermelho     C = Vermelho claro
    5 = Roxo         D = Lilás
    6 = Amarelo      E = Amarelo claro
    7 = Branco       F = Branco brilhante
*/