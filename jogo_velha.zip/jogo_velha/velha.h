#include <iostream>
#define RED "\x1B[31m"
using namespace std;

void iniciar(int board[][3]);          // Inicializa a placa a partir do zero para o número de vitórias de cada jogador.

void iniciar(int board[][3])
{
    for(int i=0; i<3; i++)
        for(int j=0; j<3; j++)
            board[i][j]=0;

}

//=================================================

char impBloco(int block);         // Imprime cada quadrado do tabuleiro.

char impBloco(int block)
{
    if(block==0)
        return ' ';
    else if(block==1)
        return '0';
    else
        return 'X';
}

//==================================================

void mostrar(int board[][3]);          // Usado para a exibição do tabuleiro na tela.

void mostrar(int board[][3])
{
    cout<<endl;
    for(int row=0 ; row<3 ; row++){
        cout<<RED" "<< impBloco(board[row][0]) <<" |";
        cout<<" "<< impBloco(board[row][1]) <<" |";
        cout<<" "<< impBloco(board[row][2]) <<endl;

        if(row!=2){
            cout<<"___ ___ ___\n"<<endl;
        }
    }
}

//================================================

void movimentar(int board[][3], int); // Para realizar o movimento no jogo.

void movimentar(int board[][3], int player)
{
    int row, col, check;
    do{
    	cout<<"\n --------------------------";
    	cout<<"\n |       Jogo da Velha    |";
    	cout<<"\n --------------------------";
        cout<<"\n Linha: ";
        cin >>row;
        cout<<"\n Coluna: ";
        cin >> col;
        row--; col--;

        check = board[row][col] || row<0 || row>2 || col<0 || col>2;
        if(check)
            cout<<"Essa casa não está vazia ou fora do intervalo 3x3"<<endl;

    }while(check);

    if(player==0)
        board[row][col]=1;
    else
        board[row][col]=-1;
}

//=================================================

int check(int *board[3]);   // Verifique se ainda há espaço em branco.

int check(int board[][3])
{
    for(int i=0 ; i<3 ; i++)
        for(int j=0 ; j<3 ; j++)
            if(board[i][j]==0)
                return 1;
    return 0;
}
//================================================

void placar(int, int &, int &); // Mostrar o placar.

void placar(int result, int &player1, int &player2)
{
    if(result==1)
        player1++;
    if(result==2)
        player2++;

    cout<<"Placar: "<<endl;
    cout<<player1<<" x "<<player2<<endl;
}
//==============================================
int checkWin(int *board[3]);        // Verifique se algum jogador ganhou a partida.

int checkWin(int board[][3])
{
    int row, col, sum;

    // Adiciona as 3 linhas para formação do tabuleiro
    for(row=0 ; row<3 ; row++){
        sum=0;

        for(col=0 ; col<3 ; col++)
            sum += board[row][col];

        if(sum==3)
            return 1;
        if(sum==-3)
            return -1;
    } 
}
//=================================================
int jogo(int board[][3]);           // Para garantir que vão jogar o jogo inteiro.

int jogo(int board[][3])
{
    int turn=0, cont, win;

    do{
    		system("cls");
        mostrar(board);
        cout<<"Jogador "<<1+turn%2<<endl;
        movimentar(board, turn%2);
        turn++;

        cont=check(board);
        win = checkWin(board);
    }while(cont && !win);

    if(win==1){
        cout<<"Jogador 1 ganhou!\n"<<endl;
        return 1;
    }else
        if(win==-1){
            cout<<"Jogador 2 ganhou!\n"<<endl;
            return 2;
    }else
        cout<<"Que pena a velha apareceu quer tentar novamente?"<<endl;
    return 0;
}

